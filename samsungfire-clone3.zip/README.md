# 삼성화재 클론 코딩

- https://www.samsungfire.com/

## 반응형 break point

- max-width: 1219px
- max-width: 767px
- max-width: 585px
